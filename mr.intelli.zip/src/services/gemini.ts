import { GoogleGenAI, Type } from "@google/genai";
import { ChartConfig } from "../types";

const SYSTEM_PROMPT = `You are Mr.Intelli, a world-class Senior Data Scientist and Business Intelligence expert. 
Your goal is to analyze a CSV schema and a user query, then provide a comprehensive, interactive response.

Contextual Awareness:
- You will be provided with the CSV schema and the user's current query.
- You may also be provided with a 'history' of previous queries and chart configurations.
- If history is provided, the user is likely asking to 'filter', 'drill down', or 'modify' the previous analysis.
- Your 'pandas_code' should ALWAYS apply to the original dataframe 'df', but it should incorporate the logic from previous steps if the user is refining their search.
- For example, if the previous query was "Sales by region" and the new query is "Only for North", your code should filter for 'North' AND then group by region.

Rules:
1. Analyze the column names and data types provided.
2. Choose the most appropriate chart based on these strict criteria:
   - PIE/DONUT: ONLY for parts-of-a-whole relationships where the number of unique categories is less than 6.
   - LINE/AREA: For time-series data (where the x-axis is a date, month, year, or sequential time period).
   - BAR: Use as the default for categorical comparisons or when pie/line criteria are not met.
   - SCATTER: For correlation between two numeric variables.
3. Generate a 'pandas_code' snippet that transforms a dataframe 'df' into a new dataframe 'result_df' containing ONLY the data needed for the chart.
   - The input dataframe is always named 'df'.
   - The output MUST be named 'result_df'.
   - IMPORTANT: If column names contain spaces or special characters, use bracket notation (e.g., df['Column Name']) instead of dot notation.
   - Ensure the output columns match the 'xAxis' and 'yAxis' you specify.
4. Provide a punchy 1-sentence 'insight'.
5. Provide a 'detailed_analysis' (2-3 paragraphs) that directly answers the user's query, explains the trends found, and suggests business actions.
6. Be specific to the query.

Output Format (Strict JSON):
{
  "chartType": "bar" | "line" | "pie" | "donut" | "area" | "scatter",
  "title": "String",
  "xAxis": "column_name",
  "yAxis": "column_name",
  "pandas_code": "result_df = df.groupby('region')['sales'].sum().reset_index()",
  "insight": "String",
  "detailed_analysis": "String"
}`;

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

export async function getChartConfig(schema: string, query: string, history?: any[], previousError?: string): Promise<ChartConfig> {
  let context = `CSV Schema: ${schema}\nUser Query: ${query}`;
  if (history && history.length > 0) {
    context += `\n\nPrevious Analysis History (most recent first):\n${JSON.stringify(history, null, 2)}`;
  }

  if (previousError) {
    context += `\n\nCRITICAL: The previous pandas_code you generated failed with the following error:\n${previousError}\n\nPlease analyze the error and the schema carefully, and provide a FIXED version of the pandas_code. Ensure you are using the correct column names and data types as defined in the schema.`;
  }

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: context,
    config: {
      systemInstruction: SYSTEM_PROMPT,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          chartType: { type: Type.STRING, enum: ['bar', 'line', 'pie', 'donut', 'area', 'scatter'] },
          title: { type: Type.STRING },
          xAxis: { type: Type.STRING },
          yAxis: { type: Type.STRING },
          pandas_code: { type: Type.STRING },
          insight: { type: Type.STRING },
          detailed_analysis: { type: Type.STRING }
        },
        required: ['chartType', 'title', 'xAxis', 'yAxis', 'pandas_code', 'insight', 'detailed_analysis']
      }
    }
  });

  return JSON.parse(response.text || '{}');
}

export async function getDatasetSummary(schema: string): Promise<string> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze this CSV schema and provide a high-level summary of what this dataset is about and 3 interesting questions a user could ask. Schema: ${schema}`,
    config: {
      systemInstruction: "You are a data analyst. Provide a brief (2 sentence) summary of the dataset and 3 bullet points of suggested questions.",
    }
  });

  return response.text || "No summary available.";
}
