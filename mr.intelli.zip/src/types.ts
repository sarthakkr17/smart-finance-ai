export interface ChartConfig {
  chartType: 'bar' | 'line' | 'pie' | 'area' | 'scatter' | 'donut';
  title: string;
  xAxis: string;
  yAxis: string;
  pandas_code: string;
  insight: string;
  detailed_analysis: string;
}

export interface CSVData {
  headers: string[];
  rows: any[];
  schema: string;
  summary?: string;
}
