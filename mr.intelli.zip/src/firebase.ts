import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged, User } from "firebase/auth";
import { getFirestore, doc, setDoc, getDoc, collection, addDoc, query, orderBy, onSnapshot, serverTimestamp, Timestamp } from "firebase/firestore";
import firebaseConfig from "../firebase-applet-config.json";

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const googleProvider = new GoogleAuthProvider();

// Auth Helper Functions
export const loginWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    const user = result.user;
    
    // Create/Update user profile in Firestore
    await setDoc(doc(db, "users", user.uid), {
      uid: user.uid,
      displayName: user.displayName,
      email: user.email,
      photoURL: user.photoURL,
      lastLogin: serverTimestamp()
    }, { merge: true });
    
    return user;
  } catch (error: any) {
    if (error.code === 'auth/popup-blocked') {
      throw new Error('Sign-in popup was blocked by your browser. Please allow popups for this site and try again.');
    } else if (error.code === 'auth/cancelled-popup-request') {
      throw new Error('Sign-in request was cancelled. Please try again.');
    } else if (error.code === 'auth/popup-closed-by-user') {
      throw new Error('Sign-in window was closed before completion. Please try again.');
    }
    console.error("Login error:", error);
    throw error;
  }
};

export const logout = () => signOut(auth);

// Firestore Helper Functions
export const saveDataset = async (userId: string, name: string, content: string, schema: string, rowCount: number) => {
  const datasetRef = collection(db, "users", userId, "datasets");
  return await addDoc(datasetRef, {
    name,
    content,
    schema,
    rowCount,
    createdAt: serverTimestamp()
  });
};

export const saveSearchHistory = async (userId: string, datasetId: string, queryText: string, chartConfig: any) => {
  const historyRef = collection(db, "users", userId, "history");
  return await addDoc(historyRef, {
    query: queryText,
    datasetId,
    chartConfig,
    createdAt: serverTimestamp()
  });
};

export const getUserDatasets = (userId: string, callback: (datasets: any[]) => void) => {
  const q = query(collection(db, "users", userId, "datasets"), orderBy("createdAt", "desc"));
  return onSnapshot(q, (snapshot) => {
    const datasets = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(datasets);
  });
};

export const getUserHistory = (userId: string, callback: (history: any[]) => void) => {
  const q = query(collection(db, "users", userId, "history"), orderBy("createdAt", "desc"));
  return onSnapshot(q, (snapshot) => {
    const history = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(history);
  });
};
