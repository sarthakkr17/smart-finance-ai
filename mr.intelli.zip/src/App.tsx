import React, { useState, useMemo, useEffect } from 'react';
import Papa from 'papaparse';
import { 
  BarChart, Bar, LineChart, Line, PieChart, Pie, AreaChart, Area, ScatterChart, Scatter,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell, ZAxis
} from 'recharts';
import { 
  Upload, Database, MessageSquare, BarChart3, 
  ChevronRight, Info, Code, FileText, AlertCircle, Loader2,
  PieChart as PieIcon, LineChart as LineIcon, AreaChart as AreaIcon, BarChart as BarIcon,
  Target, Table as TableIcon, History as HistoryIcon, Sparkles, X, LayoutDashboard,
  Cpu, Search, Settings, Layers, Zap, Download, User as UserIcon, LogOut, Trash2, Clock,
  ExternalLink
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useDropzone } from 'react-dropzone';
import html2canvas from 'html2canvas';
import { getChartConfig, getDatasetSummary } from './services/gemini';
import { ChartConfig, CSVData } from './types';
import { 
  auth, loginWithGoogle, logout, saveDataset, saveSearchHistory, 
  getUserDatasets, getUserHistory, db 
} from './firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { deleteDoc, doc } from 'firebase/firestore';

const COLORS = ['#0e91e9', '#6366f1', '#8b5cf6', '#ec4899', '#f43f5e', '#f59e0b', '#10b981'];

const Skeleton = ({ className }: { className?: string }) => (
  <div className={`animate-pulse bg-white/5 rounded-2xl ${className}`} />
);

type Tab = 'chart' | 'data' | 'code';
type SidebarTab = 'dashboard' | 'datasets' | 'history' | 'settings';

export default function App() {
  const [csvData, setCsvData] = useState<CSVData | null>(null);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [chartConfig, setChartConfig] = useState<ChartConfig | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>('chart');
  const [activeSidebarTab, setActiveSidebarTab] = useState<SidebarTab>('dashboard');
  const [history, setHistory] = useState<{ query: string; config: ChartConfig }[]>([]);
  const [summaryLoading, setSummaryLoading] = useState(false);
  const [pyodide, setPyodide] = useState<any>(null);
  const [pyodideLoading, setPyodideLoading] = useState(true);
  const [processedData, setProcessedData] = useState<any[]>([]);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [copied, setCopied] = useState(false);
  
  // Firebase State
  const [user, setUser] = useState<User | null>(null);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [userDatasets, setUserDatasets] = useState<any[]>([]);
  const [userHistory, setUserHistory] = useState<any[]>([]);
  const [authLoading, setAuthLoading] = useState(true);

  const handleLogin = async () => {
    setLoginError(null);
    try {
      await loginWithGoogle();
    } catch (err: any) {
      setLoginError(err.message || 'Failed to sign in. Please try again.');
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      setLoginError(null);
    } catch (err) {
      console.error("Logout error:", err);
    }
  };

  // Initialize Firebase Auth
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // Fetch User Data
  useEffect(() => {
    if (!user) {
      setUserDatasets([]);
      setUserHistory([]);
      return;
    }

    const unsubDatasets = getUserDatasets(user.uid, setUserDatasets);
    const unsubHistory = getUserHistory(user.uid, setUserHistory);

    return () => {
      unsubDatasets();
      unsubHistory();
    };
  }, [user]);

  // Initialize Pyodide
  useEffect(() => {
    let isMounted = true;
    async function initPyodide() {
      try {
        // Wait for the script to load if it hasn't yet
        let attempts = 0;
        while (!(window as any).loadPyodide && attempts < 50) {
          await new Promise(resolve => setTimeout(resolve, 100));
          attempts++;
        }

        if (!(window as any).loadPyodide) {
          throw new Error("Pyodide script failed to load. Please check your internet connection.");
        }

        const py = await (window as any).loadPyodide({
          indexURL: "https://cdn.jsdelivr.net/pyodide/v0.26.1/full/"
        });
        await py.loadPackage("pandas");
        if (isMounted) setPyodide(py);
      } catch (err: any) {
        console.error("Pyodide init error:", err);
        if (isMounted) setError(err.message || "Python environment offline. Falling back to JS aggregation.");
      } finally {
        if (isMounted) setPyodideLoading(false);
      }
    }
    initPyodide();
    return () => { isMounted = false; };
  }, []);

  const onDrop = (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;
    setUploadedFile(file);
    processFile(file);
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'text/csv': ['.csv'] },
    multiple: false
  } as any);

  const processFile = (file: File) => {
    Papa.parse(file, {
      header: true,
      dynamicTyping: true,
      skipEmptyLines: true,
      complete: async (results) => {
        const headers = results.meta.fields || [];
        const rows = results.data;
        
        if (rows.length === 0) {
          setError("Empty CSV file.");
          return;
        }

        const schema = headers.map(h => {
          const sample = rows.find(r => r[h] !== null && r[h] !== undefined)?.[h];
          const type = typeof sample;
          return `${h} (${type})`;
        }).join(', ');

        setCsvData({ headers, rows, schema });
        setError(null);
        setChartConfig(null);
        setProcessedData([]);
        setHistory([]);

        // Save to Firebase if logged in
        if (user) {
          try {
            await saveDataset(user.uid, file.name, Papa.unparse(rows), schema, rows.length);
          } catch (err) {
            console.error("Error saving dataset:", err);
          }
        }

        setSummaryLoading(true);
        try {
          const summary = await getDatasetSummary(schema);
          setCsvData(prev => prev ? { ...prev, summary } : null);
        } catch (err) {
          console.error("Summary error:", err);
        } finally {
          setSummaryLoading(false);
        }
      },
      error: (err) => {
        setError("CSV Parse Error: " + err.message);
      }
    });
  };

  const runPythonAnalysis = async (config: ChartConfig, data: any[]) => {
    if (!pyodide) return;
    
    try {
      const csvString = Papa.unparse(data);
      pyodide.globals.set("csv_content", csvString);
      
      const pythonScript = `
import pandas as pd
import io
import json

df = pd.read_csv(io.StringIO(csv_content))
${config.pandas_code}

if 'result_df' in locals():
    output = result_df.head(20).to_json(orient='records')
else:
    output = "[]"
output
      `;
      
      const resultJson = await pyodide.runPythonAsync(pythonScript);
      setProcessedData(JSON.parse(resultJson));
    } catch (err: any) {
      console.error("Python execution error:", err);
      throw new Error(err.message || "Unknown Python error");
    }
  };

  const handleAnalyze = async (customQuery?: string) => {
    const targetQuery = customQuery || query;
    if (!csvData || !targetQuery) return;
    
    setLoading(true);
    setError(null);
    try {
      let config = await getChartConfig(csvData.schema, targetQuery, history);
      
      try {
        await runPythonAnalysis(config, csvData.rows);
        setChartConfig(config);
        setHistory(prev => [{ query: targetQuery, config }, ...prev].slice(0, 5));
        
        // Save to Firebase history if logged in
        if (user) {
          saveSearchHistory(user.uid, uploadedFile?.name || 'unknown', targetQuery, config);
        }
      } catch (pythonErr: any) {
        console.warn("First attempt failed, asking Gemini to fix code...", pythonErr.message);
        // Retry once with error message
        config = await getChartConfig(csvData.schema, targetQuery, history, pythonErr.message);
        await runPythonAnalysis(config, csvData.rows);
        setChartConfig(config);
        setHistory(prev => [{ query: targetQuery, config }, ...prev].slice(0, 5));
        
        if (user) {
          saveSearchHistory(user.uid, uploadedFile?.name || 'unknown', targetQuery, config);
        }
      }

      setActiveTab('chart');
      if (!customQuery) setQuery('');
    } catch (err: any) {
      console.error("Analysis error:", err);
      setError("Analysis failed. Try a different query.");
    } finally {
      setLoading(false);
    }
  };

  const downloadChart = async () => {
    const chartElement = document.getElementById('chart-container');
    if (!chartElement) return;
    
    try {
      const canvas = await html2canvas(chartElement, {
        backgroundColor: '#0f172a',
        scale: 2,
        logging: false,
        useCORS: true,
        allowTaint: true
      });
      
      const link = document.createElement('a');
      link.download = `mr-intelli-${chartConfig?.title.toLowerCase().replace(/\s+/g, '-') || 'chart'}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch (err) {
      console.error("Download error:", err);
      setError("Failed to download chart image.");
    }
  };

  const downloadProcessedData = () => {
    if (processedData.length === 0) return;
    const csv = Papa.unparse(processedData);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `processed-data-${new Date().getTime()}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const clearData = () => {
    setCsvData(null);
    setUploadedFile(null);
    setChartConfig(null);
    setProcessedData([]);
    setHistory([]);
    setQuery('');
    setError(null);
  };

  const loadSavedDataset = (dataset: any) => {
    Papa.parse(dataset.content, {
      header: true,
      dynamicTyping: true,
      skipEmptyLines: true,
      complete: (results) => {
        setCsvData({
          headers: results.meta.fields || [],
          rows: results.data,
          schema: dataset.schema
        });
        setUploadedFile({ name: dataset.name } as File);
        setChartConfig(null);
        setProcessedData([]);
        setHistory([]);
        setActiveSidebarTab('dashboard');
      }
    });
  };

  const deleteDataset = async (id: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, "users", user.uid, "datasets", id));
    } catch (err) {
      console.error("Delete error:", err);
    }
  };

  const deleteHistory = async (id: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, "users", user.uid, "history", id));
    } catch (err) {
      console.error("Delete error:", err);
    }
  };

  const renderChart = () => {
    if (!chartConfig || processedData.length === 0) return null;

    const commonProps = {
      data: processedData,
      margin: { top: 20, right: 30, left: 20, bottom: 60 }
    };

    const axisStyle = {
      fontSize: 12,
      fontFamily: 'Inter',
      fill: '#94a3b8'
    };

    const tooltipStyle = {
      backgroundColor: '#0f172a',
      border: '1px solid rgba(255,255,255,0.1)',
      borderRadius: '12px',
      color: '#f8fafc'
    };

    switch (chartConfig.chartType) {
      case 'bar':
        return (
          <BarChart {...commonProps}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
            <XAxis dataKey={chartConfig.xAxis} angle={-45} textAnchor="end" height={60} tick={axisStyle} />
            <YAxis tick={axisStyle} />
            <Tooltip contentStyle={tooltipStyle} cursor={{ fill: 'rgba(255,255,255,0.05)' }} />
            <Legend wrapperStyle={{ paddingTop: 20 }} />
            <Bar dataKey={chartConfig.yAxis} fill="#0e91e9" radius={[6, 6, 0, 0]} />
          </BarChart>
        );
      case 'line':
        return (
          <LineChart {...commonProps}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
            <XAxis dataKey={chartConfig.xAxis} angle={-45} textAnchor="end" height={60} tick={axisStyle} />
            <YAxis tick={axisStyle} />
            <Tooltip contentStyle={tooltipStyle} />
            <Legend wrapperStyle={{ paddingTop: 20 }} />
            <Line type="monotone" dataKey={chartConfig.yAxis} stroke="#0e91e9" strokeWidth={3} dot={{ r: 4, fill: '#0e91e9', strokeWidth: 0 }} activeDot={{ r: 6, strokeWidth: 0 }} />
          </LineChart>
        );
      case 'area':
        return (
          <AreaChart {...commonProps}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
            <XAxis dataKey={chartConfig.xAxis} angle={-45} textAnchor="end" height={60} tick={axisStyle} />
            <YAxis tick={axisStyle} />
            <Tooltip contentStyle={tooltipStyle} />
            <Legend wrapperStyle={{ paddingTop: 20 }} />
            <Area type="monotone" dataKey={chartConfig.yAxis} stroke="#0e91e9" fill="#0e91e9" fillOpacity={0.1} strokeWidth={3} />
          </AreaChart>
        );
      case 'pie':
      case 'donut':
        return (
          <PieChart>
            <Pie
              data={processedData}
              dataKey={chartConfig.yAxis}
              nameKey={chartConfig.xAxis}
              cx="50%"
              cy="50%"
              innerRadius={chartConfig.chartType === 'donut' ? "60%" : 0}
              outerRadius="80%"
              paddingAngle={2}
              stroke="rgba(15, 23, 42, 0.5)"
              strokeWidth={2}
              label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
              labelLine={{ stroke: 'rgba(255,255,255,0.2)', strokeWidth: 1 }}
            >
              {processedData.map((_, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip 
              contentStyle={tooltipStyle}
              itemStyle={{ color: '#fff' }}
              formatter={(value: any) => [value.toLocaleString(), chartConfig.yAxis]}
            />
            <Legend 
              verticalAlign="bottom" 
              height={36}
              wrapperStyle={{ paddingTop: 40, fontSize: '11px' }}
            />
          </PieChart>
        );
      case 'scatter':
        return (
          <ScatterChart {...commonProps}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
            <XAxis dataKey={chartConfig.xAxis} name={chartConfig.xAxis} tick={axisStyle} />
            <YAxis dataKey={chartConfig.yAxis} name={chartConfig.yAxis} tick={axisStyle} />
            <Tooltip contentStyle={tooltipStyle} cursor={{ strokeDasharray: '3 3' }} />
            <Legend wrapperStyle={{ paddingTop: 20 }} />
            <Scatter name={chartConfig.title} data={processedData} fill="#0e91e9" />
          </ScatterChart>
        );
      default:
        return null;
    }
  };

  const chartTypes: { id: ChartConfig['chartType']; icon: any; label: string }[] = [
    { id: 'bar', icon: BarIcon, label: 'Bar' },
    { id: 'line', icon: LineIcon, label: 'Line' },
    { id: 'pie', icon: PieIcon, label: 'Pie' },
    { id: 'donut', icon: Target, label: 'Donut' },
    { id: 'area', icon: AreaIcon, label: 'Area' },
    { id: 'scatter', icon: Database, label: 'Scatter' },
  ];

  const suggestedQuestions = useMemo(() => {
    if (!csvData?.summary) return [];
    const lines = csvData.summary.split('\n');
    return lines
      .filter(l => l.trim().startsWith('•') || l.trim().startsWith('-') || /^\d+\./.test(l.trim()))
      .map(l => l.replace(/^[•\-\d.]+\s*/, '').trim())
      .slice(0, 3);
  }, [csvData?.summary]);

  return (
    <div className="min-h-screen bg-dark-950 text-dark-100 font-sans selection:bg-brand-500/30 selection:text-brand-100">
      {/* Sidebar */}
      <aside className="fixed left-0 top-0 h-full w-72 glass-panel border-r border-white/5 z-50 hidden lg:flex flex-col p-6">
        <div className="flex items-center gap-3 mb-12">
          <div className="bg-brand-600 p-2.5 rounded-2xl shadow-lg shadow-brand-900/20">
            <Cpu className="text-white w-6 h-6" />
          </div>
          <div>
            <h1 className="font-bold text-lg tracking-tight text-white">Mr.Intelli</h1>
            <p className="text-[10px] text-brand-400 font-black uppercase tracking-widest">Enterprise AI</p>
          </div>
        </div>

        <nav className="flex-1 space-y-2">
          <button 
            onClick={() => setActiveSidebarTab('dashboard')}
            className={`sidebar-item w-full ${activeSidebarTab === 'dashboard' ? 'sidebar-item-active' : 'sidebar-item-inactive'}`}
          >
            <LayoutDashboard className="w-5 h-5" />
            <span className="font-semibold text-sm">Dashboard</span>
          </button>
          <button 
            onClick={() => setActiveSidebarTab('datasets')}
            className={`sidebar-item w-full ${activeSidebarTab === 'datasets' ? 'sidebar-item-active' : 'sidebar-item-inactive'}`}
          >
            <Layers className="w-5 h-5" />
            <span className="font-semibold text-sm">Datasets</span>
          </button>
          <button 
            onClick={() => setActiveSidebarTab('history')}
            className={`sidebar-item w-full ${activeSidebarTab === 'history' ? 'sidebar-item-active' : 'sidebar-item-inactive'}`}
          >
            <HistoryIcon className="w-5 h-5" />
            <span className="font-semibold text-sm">History</span>
          </button>
          <button 
            onClick={() => setActiveSidebarTab('settings')}
            className={`sidebar-item w-full ${activeSidebarTab === 'settings' ? 'sidebar-item-active' : 'sidebar-item-inactive'}`}
          >
            <Settings className="w-5 h-5" />
            <span className="font-semibold text-sm">Settings</span>
          </button>
        </nav>

        <div className="mt-auto space-y-4">
          {/* User Profile / Login */}
          <div className="pt-4 border-t border-white/10">
            {loginError && (
              <div className="mb-4 p-3 rounded-xl bg-red-500/20 border border-red-500/30 text-red-200 text-[10px] flex items-start gap-2">
                <AlertCircle className="w-3 h-3 shrink-0 mt-0.5" />
                <span>{loginError}</span>
              </div>
            )}
            {user ? (
              <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
                <div className="flex items-center gap-3 mb-4">
                  <img src={user.photoURL || ''} alt="" className="w-10 h-10 rounded-xl border border-white/10" referrerPolicy="no-referrer" />
                  <div className="overflow-hidden">
                    <p className="text-sm font-bold text-white truncate">{user.displayName}</p>
                    <p className="text-[10px] text-dark-500 truncate">{user.email}</p>
                  </div>
                </div>
                <button 
                  onClick={handleLogout}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-white/5 hover:bg-red-500/10 text-dark-400 hover:text-red-400 text-xs font-bold transition-all border border-white/5"
                >
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </button>
              </div>
            ) : (
              <button 
                onClick={handleLogin}
                className="w-full flex items-center justify-center gap-3 py-4 rounded-2xl bg-brand-600 hover:bg-brand-500 text-white font-bold transition-all shadow-lg shadow-brand-900/20"
              >
                <UserIcon className="w-5 h-5" />
                Sign In
              </button>
            )}
          </div>

          <div className="p-4 rounded-2xl bg-brand-600/10 border border-brand-500/20">
            <div className="flex items-center gap-2 mb-2">
              <Zap className="w-4 h-4 text-brand-400" />
              <span className="text-xs font-bold text-brand-100">System Status</span>
            </div>
            <div className="flex items-center justify-between text-[10px] text-dark-400 font-medium">
              <span>Python Engine</span>
              <span className={pyodideLoading ? "text-amber-400" : "text-emerald-400"}>
                {pyodideLoading ? "Initializing..." : "Online"}
              </span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="lg:ml-72 p-8 lg:p-12">
        {activeSidebarTab === 'dashboard' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
              <div>
                <h2 className="text-3xl font-bold text-white tracking-tight mb-2">Data Intelligence</h2>
                <p className="text-dark-400 font-medium">Analyze, visualize, and extract insights from your datasets.</p>
              </div>
              <div className="flex items-center gap-4">
                {csvData && (
                  <button 
                    onClick={clearData}
                    className="flex items-center gap-2 px-4 py-3 bg-white/5 hover:bg-white/10 text-dark-400 hover:text-white rounded-2xl font-bold transition-all border border-white/5"
                  >
                    <X className="w-5 h-5" />
                    <span className="hidden sm:inline">Clear</span>
                  </button>
                )}
                <div {...getRootProps()} className="relative group">
                  <input {...getInputProps()} />
                  <button className={`flex items-center gap-2 px-6 py-3 ${isDragActive ? 'bg-brand-500' : 'bg-brand-600'} hover:bg-brand-500 text-white rounded-2xl font-bold transition-all shadow-lg shadow-brand-900/20 active:scale-95`}>
                    <Upload className="w-5 h-5" />
                    {isDragActive ? "Drop CSV Here" : "Import CSV"}
                  </button>
                </div>
              </div>
            </header>

            <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
              {/* Left Column: Input & Summary */}
              <div className="xl:col-span-4 space-y-8">
                {/* Query Input */}
                <section className="glass-panel rounded-[2rem] p-8 shadow-2xl shadow-black/20">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="bg-white/5 p-2 rounded-xl">
                      <Search className="w-5 h-5 text-brand-400" />
                    </div>
                    <h3 className="font-bold text-sm uppercase tracking-widest text-dark-300">Analysis Agent</h3>
                  </div>
                  
                  <textarea
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Ask a question about your data..."
                    className="w-full h-40 p-5 bg-dark-950/50 border border-white/5 rounded-2xl focus:ring-2 focus:ring-brand-500/50 focus:border-brand-500 transition-all resize-none text-white placeholder:text-dark-600 font-medium text-sm"
                  />

                  {suggestedQuestions.length > 0 && (
                    <div className="mt-6 space-y-3">
                      <p className="text-[10px] font-black text-dark-500 uppercase tracking-widest ml-1">Suggestions</p>
                      <div className="flex flex-col gap-2">
                        {suggestedQuestions.map((q, i) => (
                          <button
                            key={i}
                            onClick={() => handleAnalyze(q)}
                            className="text-left px-4 py-3 bg-white/5 hover:bg-white/10 text-dark-300 rounded-xl text-xs font-semibold transition-all border border-white/5 flex items-center gap-3 group"
                          >
                            <Sparkles className="w-3.5 h-3.5 text-brand-400 opacity-50 group-hover:opacity-100" />
                            <span className="line-clamp-1">{q}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  <button
                    onClick={() => handleAnalyze()}
                    disabled={loading || !csvData || !query}
                    className="w-full mt-8 bg-brand-600 hover:bg-brand-500 disabled:bg-dark-800 disabled:text-dark-600 disabled:cursor-not-allowed text-white font-bold py-4 rounded-2xl transition-all flex items-center justify-center gap-3 shadow-xl shadow-brand-900/20 active:scale-[0.98]"
                  >
                    {loading ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <Zap className="w-5 h-5" />
                    )}
                    {loading ? "Analyzing..." : "Run Intelligence"}
                  </button>
                </section>

                {/* Dataset Info */}
                {csvData && (
                  <motion.section 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="glass-panel rounded-[2rem] p-8"
                  >
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-3">
                        <div className="bg-white/5 p-2 rounded-xl">
                          <Database className="w-5 h-5 text-brand-400" />
                        </div>
                        <h3 className="font-bold text-sm uppercase tracking-widest text-dark-300">Dataset</h3>
                      </div>
                      <span className="text-[10px] font-bold text-brand-400 bg-brand-500/10 px-2.5 py-1 rounded-full border border-brand-500/20">
                        {csvData.rows.length.toLocaleString()} Rows
                      </span>
                    </div>

                    {summaryLoading ? (
                      <div className="flex items-center justify-center py-12">
                        <Loader2 className="w-8 h-8 animate-spin text-brand-500 opacity-20" />
                      </div>
                    ) : csvData.summary ? (
                      <div className="space-y-4">
                        <p className="text-sm text-dark-400 leading-relaxed font-medium">
                          {csvData.summary.split('\n')[0]}
                        </p>
                        <div className="flex flex-wrap gap-2 pt-4 border-t border-white/5">
                          {csvData.headers.slice(0, 8).map(h => (
                            <span key={h} className="px-2.5 py-1 bg-white/5 border border-white/5 rounded-lg text-[10px] font-mono font-bold text-dark-500">
                              {h}
                            </span>
                          ))}
                          {csvData.headers.length > 8 && (
                            <span className="px-2.5 py-1 text-[10px] font-bold text-dark-600">+{csvData.headers.length - 8} more</span>
                          )}
                        </div>
                      </div>
                    ) : null}
                  </motion.section>
                )}
              </div>

              {/* Right Column: Results */}
              <div className="xl:col-span-8 space-y-8">
                <AnimatePresence mode="wait">
                  {loading ? (
                    <motion.div
                      key="loading"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="space-y-8"
                    >
                      <div className="flex justify-between items-center">
                        <Skeleton className="h-12 w-64" />
                        <Skeleton className="h-12 w-48" />
                      </div>
                      <section className="glass-panel rounded-[3rem] p-10 h-[600px] flex flex-col gap-8">
                        <div className="flex justify-between">
                          <div className="space-y-4">
                            <Skeleton className="h-10 w-96" />
                            <Skeleton className="h-4 w-64" />
                          </div>
                          <Skeleton className="h-10 w-10" />
                        </div>
                        <Skeleton className="flex-1 w-full" />
                      </section>
                      <Skeleton className="h-64 w-full rounded-[3rem]" />
                    </motion.div>
                  ) : !chartConfig ? (
                    <motion.div 
                      key="empty"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="h-full min-h-[600px] glass-panel rounded-[3rem] border-dashed border-white/10 flex flex-col items-center justify-center text-center p-12"
                    >
                      <div className="bg-white/5 p-10 rounded-full mb-8 relative">
                        <div className="absolute inset-0 bg-brand-500/10 blur-3xl rounded-full" />
                        <BarChart3 className="w-20 h-20 text-brand-500 relative z-10" />
                      </div>
                      <h3 className="text-3xl font-bold text-white mb-4 tracking-tight">Intelligence Ready</h3>
                      <p className="text-dark-400 max-w-md leading-relaxed font-medium text-lg">
                        Upload your dataset and ask a question to generate real-time visualizations and deep business insights.
                      </p>
                    </motion.div>
                  ) : (
                    <motion.div 
                      key="results"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-8"
                    >
                      {/* Tabs & Controls */}
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                        <div className="bg-dark-900/80 p-1.5 rounded-2xl border border-white/5 inline-flex gap-1 self-start">
                          {(['chart', 'data', 'code'] as Tab[]).map((tab) => (
                            <button
                              key={tab}
                              onClick={() => setActiveTab(tab)}
                              className={`px-8 py-2.5 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${
                                activeTab === tab 
                                ? 'bg-brand-600 text-white shadow-lg shadow-brand-900/20' 
                                : 'text-dark-500 hover:text-dark-300 hover:bg-white/5'
                              }`}
                            >
                              {tab}
                            </button>
                          ))}
                        </div>

                          <div className="flex items-center gap-2 p-1.5 bg-dark-900/80 rounded-2xl border border-white/5 overflow-x-auto no-scrollbar">
                            <button 
                              onClick={downloadProcessedData}
                              className="p-2.5 rounded-xl text-dark-600 hover:text-brand-400 hover:bg-white/5 transition-all"
                              title="Download Processed CSV"
                            >
                              <FileText className="w-4 h-4" />
                            </button>
                            <div className="w-px h-4 bg-white/10 mx-1" />
                            {chartTypes.map((type) => (
                            <button
                              key={type.id}
                              onClick={() => setChartConfig({ ...chartConfig, chartType: type.id })}
                              className={`p-2.5 rounded-xl transition-all ${
                                chartConfig.chartType === type.id
                                  ? 'bg-white/10 text-brand-400'
                                  : 'text-dark-600 hover:text-dark-400'
                              }`}
                              title={type.label}
                            >
                              <type.icon className="w-4 h-4" />
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Visualization Panel */}
                      <section id="chart-container" className="glass-panel rounded-[3rem] p-10 shadow-2xl shadow-black/40 relative">
                        {activeTab === 'chart' && (
                          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-10">
                            <div className="flex items-start justify-between">
                              <div>
                                <h3 className="text-4xl font-bold text-white tracking-tight leading-tight max-w-2xl">{chartConfig.title}</h3>
                                <div className="flex items-center gap-6 mt-6">
                                  <div className="flex items-center gap-2.5">
                                    <div className="w-2.5 h-2.5 bg-brand-500 rounded-full" />
                                    <span className="text-xs font-bold text-dark-500 uppercase tracking-widest">Dimension:</span>
                                    <span className="text-xs font-bold text-white uppercase tracking-widest">{chartConfig.xAxis}</span>
                                  </div>
                                  <div className="flex items-center gap-2.5">
                                    <div className="w-2.5 h-2.5 bg-dark-700 rounded-full" />
                                    <span className="text-xs font-bold text-dark-500 uppercase tracking-widest">Metric:</span>
                                    <span className="text-xs font-bold text-white uppercase tracking-widest">{chartConfig.yAxis}</span>
                                  </div>
                                </div>
                              </div>
                              
                              <button 
                                onClick={downloadChart}
                                className="p-3 bg-white/5 hover:bg-white/10 text-dark-400 hover:text-white rounded-2xl transition-all border border-white/5 group"
                                title="Download as Image"
                              >
                                <Download className="w-5 h-5 group-hover:scale-110 transition-transform" />
                              </button>
                            </div>

                            <div className="h-[450px] w-full">
                              <ResponsiveContainer width="100%" height="100%">
                                {renderChart() || <div className="flex items-center justify-center h-full text-dark-600">No data available</div>}
                              </ResponsiveContainer>
                            </div>
                          </motion.div>
                        )}

                        {activeTab === 'data' && (
                          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="overflow-hidden rounded-3xl border border-white/5">
                            <div className="overflow-x-auto max-h-[500px]">
                              <table className="w-full text-left border-collapse">
                                <thead className="sticky top-0 bg-dark-800 z-10">
                                  <tr>
                                    {csvData?.headers.map(h => (
                                      <th key={h} className="px-6 py-4 text-[10px] font-black text-dark-500 uppercase tracking-widest border-b border-white/5">
                                        {h}
                                      </th>
                                    ))}
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-white/5">
                                  {csvData?.rows.slice(0, 50).map((row, i) => (
                                    <tr key={i} className="hover:bg-white/5 transition-colors">
                                      {csvData.headers.map(h => (
                                        <td key={h} className="px-6 py-4 text-xs text-dark-300 font-medium">
                                          {String(row[h])}
                                        </td>
                                      ))}
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </motion.div>
                        )}

                        {activeTab === 'code' && (
                          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                            <div className="bg-dark-950 rounded-3xl p-10 border border-white/5 relative group">
                              <button 
                                onClick={() => {
                                  navigator.clipboard.writeText(chartConfig.pandas_code);
                                  setCopied(true);
                                  setTimeout(() => setCopied(false), 2000);
                                }}
                                className="absolute top-8 right-8 p-3 bg-white/5 hover:bg-white/10 text-dark-400 hover:text-brand-400 rounded-2xl transition-all border border-white/5 opacity-0 group-hover:opacity-100 flex items-center gap-2"
                                title="Copy Code"
                              >
                                {copied ? (
                                  <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-400">Copied!</span>
                                ) : (
                                  <Download className="w-5 h-5 rotate-180" />
                                )}
                              </button>
                              <div className="flex items-center gap-4 mb-8">
                                <div className="bg-brand-600/10 p-3 rounded-2xl">
                                  <Code className="w-6 h-6 text-brand-400" />
                                </div>
                                <div>
                                  <h4 className="font-bold text-white">Pandas Logic</h4>
                                  <p className="text-xs text-dark-500 font-medium">Automated data transformation pipeline</p>
                                </div>
                              </div>
                              <pre className="text-sm font-mono text-brand-300 leading-relaxed overflow-x-auto p-6 bg-black/20 rounded-2xl border border-white/5">
                                {chartConfig.pandas_code}
                              </pre>
                            </div>
                          </motion.div>
                        )}
                      </section>

                      {/* Insights Panel */}
                      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                        <div className="lg:col-span-12 glass-panel rounded-[3rem] p-10 relative overflow-hidden">
                          <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none">
                            <Sparkles className="w-64 h-64 text-brand-500" />
                          </div>
                          
                          <div className="relative z-10">
                            <div className="flex items-center gap-4 mb-8">
                              <div className="bg-brand-600/20 p-3 rounded-2xl">
                                <Info className="w-6 h-6 text-brand-400" />
                              </div>
                              <h4 className="font-bold text-white uppercase tracking-[0.2em] text-xs">Executive Summary</h4>
                            </div>
                            
                            <div className="space-y-8">
                              <p className="text-3xl font-bold text-white leading-tight tracking-tight">
                                {chartConfig.insight}
                              </p>
                              <div className="h-px bg-white/10 w-24" />
                              <p className="text-lg text-dark-400 font-medium leading-relaxed whitespace-pre-line max-w-4xl">
                                {chartConfig.detailed_analysis}
                              </p>
                            </div>
                          </div>
                        </div>
                      </section>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </motion.div>
        )}

        {activeSidebarTab === 'datasets' && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
            <header className="mb-12">
              <h2 className="text-3xl font-bold text-white tracking-tight mb-2">My Datasets</h2>
              <p className="text-dark-400 font-medium">Manage and reload your previously uploaded data sources.</p>
            </header>

            {!user ? (
              <div className="glass-panel rounded-[3rem] p-20 text-center flex flex-col items-center justify-center">
                <div className="bg-white/5 p-8 rounded-full mb-6">
                  <UserIcon className="w-12 h-12 text-dark-600" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Sign in to save datasets</h3>
                <p className="text-dark-500 mb-8 max-w-xs">Your data will be securely stored in your private cloud workspace.</p>
                <button onClick={handleLogin} className="px-8 py-3 bg-brand-600 hover:bg-brand-500 text-white font-bold rounded-2xl transition-all">
                  Sign In with Google
                </button>
                {loginError && <p className="mt-4 text-red-400 text-sm">{loginError}</p>}
              </div>
            ) : userDatasets.length === 0 ? (
              <div className="glass-panel rounded-[3rem] p-20 text-center flex flex-col items-center justify-center border-dashed border-white/10">
                <Database className="w-16 h-16 text-dark-700 mb-6" />
                <h3 className="text-xl font-bold text-white mb-2">No datasets found</h3>
                <p className="text-dark-500">Upload your first CSV on the dashboard to see it here.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {userDatasets.map((ds) => (
                  <div key={ds.id} className="glass-panel rounded-3xl p-6 group hover:border-brand-500/30 transition-all">
                    <div className="flex items-start justify-between mb-6">
                      <div className="bg-brand-600/10 p-3 rounded-2xl">
                        <FileText className="w-6 h-6 text-brand-400" />
                      </div>
                      <button 
                        onClick={() => deleteDataset(ds.id)}
                        className="p-2 text-dark-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                    <h4 className="font-bold text-white mb-1 truncate">{ds.name}</h4>
                    <p className="text-xs text-dark-500 mb-6">{ds.rowCount.toLocaleString()} rows • {new Date(ds.createdAt?.toDate()).toLocaleDateString()}</p>
                    <button 
                      onClick={() => loadSavedDataset(ds)}
                      className="w-full py-3 bg-white/5 hover:bg-brand-600 text-dark-300 hover:text-white font-bold rounded-xl transition-all border border-white/5 text-sm"
                    >
                      Load Dataset
                    </button>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {activeSidebarTab === 'history' && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
            <header className="mb-12">
              <h2 className="text-3xl font-bold text-white tracking-tight mb-2">Analysis History</h2>
              <p className="text-dark-400 font-medium">Review your past queries and the insights generated.</p>
            </header>

            {!user ? (
              <div className="glass-panel rounded-[3rem] p-20 text-center flex flex-col items-center justify-center">
                <div className="bg-white/5 p-8 rounded-full mb-6">
                  <UserIcon className="w-12 h-12 text-dark-600" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Sign in to view history</h3>
                <button onClick={handleLogin} className="px-8 py-3 bg-brand-600 hover:bg-brand-500 text-white font-bold rounded-2xl transition-all">
                  Sign In with Google
                </button>
                {loginError && <p className="mt-4 text-red-400 text-sm">{loginError}</p>}
              </div>
            ) : userHistory.length === 0 ? (
              <div className="glass-panel rounded-[3rem] p-20 text-center flex flex-col items-center justify-center border-dashed border-white/10">
                <Clock className="w-16 h-16 text-dark-700 mb-6" />
                <h3 className="text-xl font-bold text-white mb-2">No history yet</h3>
                <p className="text-dark-500">Your AI-powered insights will appear here as you explore data.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {userHistory.map((h) => (
                  <div key={h.id} className="glass-panel rounded-3xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-6 group hover:border-brand-500/30 transition-all">
                    <div className="flex items-center gap-4 flex-1">
                      <div className="bg-white/5 p-3 rounded-2xl">
                        <MessageSquare className="w-5 h-5 text-brand-400" />
                      </div>
                      <div>
                        <p className="text-white font-bold mb-1">"{h.query}"</p>
                        <p className="text-[10px] text-dark-500 uppercase tracking-widest font-black">
                          Dataset: {h.datasetId} • {new Date(h.createdAt?.toDate()).toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <button 
                        onClick={() => {
                          setChartConfig(h.chartConfig);
                          setActiveSidebarTab('dashboard');
                          setActiveTab('chart');
                        }}
                        className="px-6 py-2.5 bg-white/5 hover:bg-brand-600 text-dark-300 hover:text-white font-bold rounded-xl transition-all border border-white/5 text-xs"
                      >
                        View Result
                      </button>
                      <button 
                        onClick={() => deleteHistory(h.id)}
                        className="p-2.5 text-dark-600 hover:text-red-400 transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {activeSidebarTab === 'settings' && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
            <header className="mb-12">
              <h2 className="text-3xl font-bold text-white tracking-tight mb-2">Settings</h2>
              <p className="text-dark-400 font-medium">Configure your workspace and AI preferences.</p>
            </header>

            <div className="max-w-3xl space-y-8">
              <section className="glass-panel rounded-[2rem] p-8">
                <h3 className="text-lg font-bold text-white mb-6">Profile Settings</h3>
                {user ? (
                  <div className="space-y-6">
                    <div className="flex items-center gap-6 p-6 bg-white/5 rounded-2xl border border-white/5">
                      <img src={user.photoURL || ''} alt="" className="w-20 h-20 rounded-3xl border-2 border-brand-500/20" />
                      <div>
                        <p className="text-xl font-bold text-white mb-1">{user.displayName}</p>
                        <p className="text-dark-500 font-medium">{user.email}</p>
                        <div className="flex items-center gap-2 mt-3">
                          <span className="px-2.5 py-1 bg-emerald-500/10 text-emerald-400 text-[10px] font-bold rounded-full border border-emerald-500/20 uppercase tracking-widest">Verified Account</span>
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                        <p className="text-[10px] font-black text-dark-500 uppercase tracking-widest mb-1">User ID</p>
                        <p className="text-xs font-mono text-dark-300 truncate">{user.uid}</p>
                      </div>
                      <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                        <p className="text-[10px] font-black text-dark-500 uppercase tracking-widest mb-1">Account Created</p>
                        <p className="text-xs font-medium text-dark-300">{user.metadata.creationTime}</p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="p-12 text-center bg-white/5 rounded-3xl border border-dashed border-white/10">
                    <p className="text-dark-500 font-medium mb-6">Sign in to manage your profile and data.</p>
                    <button onClick={handleLogin} className="px-8 py-3 bg-brand-600 hover:bg-brand-500 text-white font-bold rounded-2xl transition-all">
                      Sign In with Google
                    </button>
                    {loginError && <p className="mt-4 text-red-400 text-sm">{loginError}</p>}
                  </div>
                )}
              </section>

              <section className="glass-panel rounded-[2rem] p-8">
                <h3 className="text-lg font-bold text-white mb-6">AI Engine</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                    <div>
                      <p className="font-bold text-white text-sm">Gemini 3 Flash</p>
                      <p className="text-xs text-dark-500">Optimized for speed and complex data reasoning</p>
                    </div>
                    <div className="px-3 py-1 bg-brand-500/10 text-brand-400 text-[10px] font-bold rounded-full border border-brand-500/20 uppercase tracking-widest">Active</div>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 opacity-50">
                    <div>
                      <p className="font-bold text-white text-sm">Pyodide (WASM)</p>
                      <p className="text-xs text-dark-500">Local Python execution for data security</p>
                    </div>
                    <div className="px-3 py-1 bg-emerald-500/10 text-emerald-400 text-[10px] font-bold rounded-full border border-emerald-500/20 uppercase tracking-widest">Running</div>
                  </div>
                </div>
              </section>

              <section className="glass-panel rounded-[2rem] p-8">
                <h3 className="text-lg font-bold text-white mb-6">Support & Resources</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <a href="#" className="flex items-center justify-between p-4 bg-white/5 hover:bg-white/10 rounded-2xl border border-white/5 transition-all group">
                    <div className="flex items-center gap-3">
                      <FileText className="w-5 h-5 text-dark-500 group-hover:text-brand-400" />
                      <span className="text-sm font-bold text-dark-300">Documentation</span>
                    </div>
                    <ExternalLink className="w-4 h-4 text-dark-600" />
                  </a>
                  <a href="#" className="flex items-center justify-between p-4 bg-white/5 hover:bg-white/10 rounded-2xl border border-white/5 transition-all group">
                    <div className="flex items-center gap-3">
                      <MessageSquare className="w-5 h-5 text-dark-500 group-hover:text-brand-400" />
                      <span className="text-sm font-bold text-dark-300">Community Support</span>
                    </div>
                    <ExternalLink className="w-4 h-4 text-dark-600" />
                  </a>
                </div>
              </section>
            </div>
          </motion.div>
        )}
      </main>
    </div>
  );
}
